Hungarian Rings - Puzzle Simulator

This is a simulator of the famous "Hungarian Rings" puzzle.
this is a small python program that uses the pygame library

home page: https://github.com/grigorusha/Hungarian-Rings

forum page with my other Puzzle simulators - https://twistypuzzles.com/forum/viewtopic.php?p=422931#p422931

You can create a text file with a script that describes the location of rings, balls and their colors.
Each ball can be marked with a marker (letter or number) to make the puzzle harder to solve.
I have created files for all the ring puzzles, you can download them from the "Ring" folder.
